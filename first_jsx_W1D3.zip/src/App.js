
import React from 'react';
import './App.css';

function App() {
  return (
    <div className="App">
      <h1>Hello Dojo!</h1>
      <h3>Things I need to do:</h3>
      <li>Learn React</li>
      <li>Climb Mt. Everest</li>
      <li>Run a Marathon</li>
      <li>Feed the dogs</li>
    </div>
  );
}

export default App;
